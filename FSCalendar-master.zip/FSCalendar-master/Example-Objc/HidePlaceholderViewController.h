//
//  HidePlaceholderViewController.h
//  FSCalendar
//
//  Created by dingwenchao on 3/9/16.
//  Copyright © 2016 Wenchao Ding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HidePlaceholderViewController : UIViewController


@end
