//
//  ToDo.swift
//  Pendiente
//

import Foundation

struct ToDo: Codable {
    var title: String
    var isComplete: Bool
    var dueDate: Date
    var notes: String?
    
    static let DocumentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    
    //carga los pendientes guardados
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("todos").appendingPathExtension("plist")
    
    
    //muestra los pendientes guardados para que se guarden aunque se cierre la aplicacion
    static func loadToDos() -> [ToDo]? {
        guard let codedToDos = try? Data(contentsOf: ArchiveURL) else { return nil }
        
        let propertyListDecoder = PropertyListDecoder()
        return try? propertyListDecoder.decode(Array<ToDo>.self, from: codedToDos)
    }
    
    //Muestra por default 3 pendientes genericos
    static func loadSampleToDos() -> [ToDo] {//Arreglo de pendientes
        return [
            /*ToDo(title: "Tarea 1", isComplete: false, dueDate: Date(), notes: "Nota 1"),
            ToDo(title: "Tarea 2", isComplete: false, dueDate: Date(), notes: "Nota 2"),
            ToDo(title: "Tarea 3", isComplete: false, dueDate: Date(), notes: "Nota 3")*/
        ]
    }
    
    //guarsa los poendientes
    static func saveToDos(_ todos: [ToDo]) {
        let propertyListEncoder = PropertyListEncoder()
        let codedToDos = try? propertyListEncoder.encode(todos)
        try? codedToDos?.write(to: ArchiveURL, options: .noFileProtection)
    }
    
    //formato de la fecha
    static let dueDateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter
    }()
}
