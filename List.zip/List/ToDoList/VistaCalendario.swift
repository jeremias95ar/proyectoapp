
import UIKit

class VistaCalendario: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    

    @IBOutlet weak var Mes: UILabel!
    
    @IBOutlet weak var Calendar: UICollectionView!
    var currentMonth = String()
    
    let Months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
    let DaysOfMonths = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
    var DaysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    var numberOfEmptyBox = Int()
    var PreviousNumberOfEmptyBox = Int()
    var Direction = 0
    var PositionIndex = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        currentMonth = Months[month]
        
        Mes.text = "\(currentMonth) \(year)"
    }
    
    
    
    @IBAction func Siguiente(_ sender: Any) {
        switch currentMonth {
        case "Diciembre":
            month = 0
            year += 1
            currentMonth = Months[month]
            Mes.text  = "\(currentMonth) \(year)"
            Calendar.reloadData()
        default:
            month += 1
            currentMonth = Months[month]
            Mes.text = "\(currentMonth) \(year)"
            Calendar.reloadData()
        }
    }
    
    @IBAction func Anterior(_ sender: Any) {
        switch currentMonth {
        case "Enero":
            month = 11
            year -= 1
            
            currentMonth = Months[month]
            
            Mes.text  = "\(currentMonth) \(year)"
            Calendar.reloadData()
        default:
            month -= 1
            
            currentMonth = Months[month]
            Mes.text = "\(currentMonth) \(year)"
            Calendar.reloadData()
        }
    }
    
    
   func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       
       return DaysInMonth[month]
   }
   
   func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Calendar", for: indexPath) as! DateCollectionViewCell
       cell.backgroundColor = UIColor.clear
    cell.DateLabel.text = "\(indexPath.row + 1)"
    return cell
       
   }
    

    

}
