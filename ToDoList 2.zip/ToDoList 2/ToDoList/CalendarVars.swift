
import Foundation


let date = Date()
let cal = Calendar.current

let day = cal.component(.day, from: date)
let weekday = cal.component(.weekday, from: date)
let month = cal.component(.month, from: date) - 1 
let year = cal.component(.year, from: date)

