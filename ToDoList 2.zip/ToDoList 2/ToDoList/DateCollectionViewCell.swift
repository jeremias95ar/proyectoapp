//
//  DateCollectionViewCell.swift
//  ToDoList
//
//  Created by CEDAM14 on 26/11/19.
//  Copyright © 2019 Doan Le Thieu. All rights reserved.
//

import UIKit

class DateCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var DateLabel: UILabel!
    
    
}
